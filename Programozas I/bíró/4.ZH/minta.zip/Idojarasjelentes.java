
import java.util.Map;

public class Idojarasjelentes {
    private final String varos;

    private final int hitelesseg;

    private final Map<String, Integer> elorejelzesek;

    public Idojarasjelentes(String varos, int hitelesseg, Map<String, Integer> elorejelzesek) {
        this.varos = varos;
        this.hitelesseg = hitelesseg;
        this.elorejelzesek = elorejelzesek;
    }

    public String getVaros() {
        return varos;
    }

    public float getHitelesseg() {
        return hitelesseg;
    }

    @Override
    public String toString() {
        return varos + ", " + getHitelesseg();
    }
}
